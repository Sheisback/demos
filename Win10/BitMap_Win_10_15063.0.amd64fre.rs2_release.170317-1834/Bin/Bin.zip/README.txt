when you run exploit it will stop
after calculating the hMgr pvScan0
and the worker pvScan0
if the difference is small e.g:
ffff9989825aa000
ffff9989825ac000
? ~ 0x94000
you can press any key,
other-wise exit program with X
and run again.
